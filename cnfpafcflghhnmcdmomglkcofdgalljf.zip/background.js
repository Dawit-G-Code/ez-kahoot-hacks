chrome.webRequest.onBeforeRequest.addListener(
  function (details) {
    if (details.url.includes("abstract.land/kahoot/apis"))
      return {
        redirectUrl: details.url.replace(
          "abstract.land/kahoot/apis",
          "apis.kahoot.it"
        ),
      };
    if (details.url.includes("abstract.land/kahoot"))
      return {
        redirectUrl: details.url.replace("abstract.land/kahoot", "kahoot.it"),
      };

    return { redirectUrl: details.url };
  },
  {
    urls: [
      "https://abstract.land/kahoot/reserve/session/*",
      "https://abstract.land/kahoot/rest/*",
      "https://abstract.land/kahoot/apis/profanities/nickname/*",
    ],
  },
  ["blocking"]
);

const headers = [
  { name: "Access-Control-Allow-Credential", value: "true" },
  { name: "Access-Control-Allow-Headers", value: "*" },
  { name: "Access-Control-Allow-Methods", value: "GET, POST, OPTIONS, DELETE" },
  { name: "Access-Control-Expose-Headers", value: "*" },
  { name: "Access-Control-Allow-Origin", value: "*" },
  { name: "Vary", value: "Origin,Access-Control-Allow-Origin" },
];

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.url.includes("kahoot.it")) {
      headers.forEach((header) => {
        let toEdit = details.responseHeaders.find(
          (h) => h.name.toLowerCase() === header.name.toLowerCase()
        );
        if (toEdit == undefined) {
          toEdit = header;
          details.responseHeaders.push(toEdit);
        } else toEdit.value = header.value;
      });
      return { responseHeaders: details.responseHeaders };
    }
  },
  {
    urls: [
      "https://kahoot.it/reserve/session/*",
      "https://kahoot.it/rest/*",
      "https://apis.kahoot.it/profanities/nickname/*",
    ],
  },
  ["blocking", "responseHeaders"]
);
